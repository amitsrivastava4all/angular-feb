import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormControl, NgForm } from '@angular/forms';
import { User } from 'src/models/user';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'validationdemo';
  @ViewChild('firstName')
  firstName?:ElementRef ;
  @ViewChild('uage')
  ageEle?:ElementRef;
  name:string;
  age:number;
  constructor(){
    this.name = '';
    this.age = 0;
  }
  //register(firstName:HTMLInputElement, age: HTMLInputElement):void{
  //   register(firstName:string, age:string):void{
  //   // this.name = firstName.value;
  //   // this.age = parseInt(age.value);
  //   this.name =firstName;
  //   this.age = parseInt(age);
  // }
  // register(){
  //   this.name = this.firstName?.nativeElement.value;
  //   this.age = this.ageEle?.nativeElement.value;
  // }
  register(forms:NgForm):void{
    console.log('Form is ', forms.form.controls);
    let user:User = new User();
    for(let key in forms.form.controls){
      if(key=='name'){
      user.name =  forms.form.controls[key].value;
      }
      else if(key =='age'){
        user.age =  forms.form.controls[key].value;
      }
      else if (key == 'email'){
        user.email =  forms.form.controls[key].value;
      }
      //user[key] =  forms.form.controls[key].value;

    }
    console.log('User Object is ',user);
  }
}
