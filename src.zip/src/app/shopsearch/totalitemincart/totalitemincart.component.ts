import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-totalitemincart',
  templateUrl: './totalitemincart.component.html',
  styleUrls: ['./totalitemincart.component.css']
})
export class TotalitemincartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
