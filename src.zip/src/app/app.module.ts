import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ShopsearchComponent } from './shopsearch/shopsearch.component';
import { TitleComponent } from './shopsearch/title/title.component';
import { SearchboxComponent } from './shopsearch/searchbox/searchbox.component';
import { ListComponent } from './shopsearch/list/list.component';
import { ItemComponent } from './shopsearch/list/item/item.component';
import { TotalitemincartComponent } from './shopsearch/totalitemincart/totalitemincart.component';
import {HttpClientModule} from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    ShopsearchComponent,
    TitleComponent,
    SearchboxComponent,
    ListComponent,
    ItemComponent,
    TotalitemincartComponent
  ],
  imports: [
    BrowserModule, HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
