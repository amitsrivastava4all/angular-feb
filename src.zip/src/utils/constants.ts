export class Constants{
    static URL:string = 'https://raw.githubusercontent.com/amitsrivastava4all/angular-feb/main/products.json';
}