import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { PrefixPipe } from 'src/prefix.pipe';

import { AppComponent } from './app.component';
import { CubePipe } from './cube.pipe';

@NgModule({
  declarations: [
    AppComponent, PrefixPipe, CubePipe
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
