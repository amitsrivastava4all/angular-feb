import { Component, Input, OnInit } from '@angular/core';
import Product from 'src/models/product';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  @Input()
  prods: Product[] ;
  constructor() {
    this.prods = [];
   }

  ngOnInit(): void {
  }

}
