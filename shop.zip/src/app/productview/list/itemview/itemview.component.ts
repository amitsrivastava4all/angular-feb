import { Component, Input, OnInit } from '@angular/core';
import Product from 'src/models/product';

@Component({
  selector: 'app-itemview',
  templateUrl: './itemview.component.html',
  styleUrls: ['./itemview.component.css']
})
export class ItemviewComponent implements OnInit {
  @Input()
  singleproduct : Product ;
  constructor() {
      this.singleproduct = new Product(0,"",0,"");
  }

  ngOnInit(): void {
  }

}
