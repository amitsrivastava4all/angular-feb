import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cartoperations',
  templateUrl: './cartoperations.component.html',
  styleUrls: ['./cartoperations.component.css']
})
export class CartoperationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
