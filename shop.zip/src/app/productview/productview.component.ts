import { Component, OnInit } from '@angular/core';
import  Product  from 'src/models/product';

@Component({
  selector: 'app-productview',
  templateUrl: './productview.component.html',
  styleUrls: ['./productview.component.css']
})
export class ProductviewComponent implements OnInit {
   products:Product[]= [];
  constructor() { }

  ngOnInit(): void {
    this.fetchProducts();
  }
  private jsonParser(products:any): []{
    return products.map((product:any)=>new Product(product.id, product.name, product.price, product.image));
  }
  private fetchProducts(){
    const URL:string = "https://raw.githubusercontent.com/amitsrivastava4all/angular-feb/main/products.json";
    const promise = fetch(URL);
    promise.then(response=>{
      response.json().then(data=>{
        console.log('Data is ',data);
        this.products  = this.jsonParser(data['products']);
        console.log('All Products ', this.products);
      }).catch(err=>{
        console.log('JSON Error is ',err);
      })
    }).catch(err=>{
      console.log('Fetch Call Error ');
    })
  }

}
