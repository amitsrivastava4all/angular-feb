import { Component, Input, OnInit } from '@angular/core';
import Product from 'src/models/product';

@Component({
  selector: 'app-carttotal',
  templateUrl: './carttotal.component.html',
  styleUrls: ['./carttotal.component.css']
})
export class CarttotalComponent implements OnInit {
  cartTotal:number;
  @Input()
  prods : Product[] ;
  constructor() {
    this.cartTotal = 0;
    this.prods  = [];
   }

  ngOnInit(): void {
  }
  itemInCart(){
    return this.prods.filter((product:Product)=>product.isInCart).length;
  }

}
