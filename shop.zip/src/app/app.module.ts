import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ProductviewComponent } from './productview/productview.component';
import { SearchComponent } from './productview/search/search.component';
import { ListComponent } from './productview/list/list.component';
import { ItemviewComponent } from './productview/list/itemview/itemview.component';
import { CartoperationsComponent } from './productview/list/itemview/cartoperations/cartoperations.component';
import { CarttotalComponent } from './productview/carttotal/carttotal.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductviewComponent,
    SearchComponent,
    ListComponent,
    ItemviewComponent,
    CartoperationsComponent,
    CarttotalComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
