export class Product{

    constructor(private id:number , private name:string,
         private price:number, private image:string){}
    toString():string{
        return `Id is ${this.id} Name is ${this.name} Price is ${this.price} Image URL is ${this.image}`;
    }
}