import { EventEmitter, Injectable } from "@angular/core";



@Injectable({providedIn:'root'}) // From Angular 6 (Application Wide)
export class Cart {
    eventEmitter:EventEmitter<number> = new EventEmitter<number>();
    count:number;
    constructor(){
        this.count = 0;
    }
    plus():void {
        this.count++;
        this.eventEmitter.emit(this.count); // Event Fire
    }
    read():EventEmitter<number>{
        return this.eventEmitter;
    }
}