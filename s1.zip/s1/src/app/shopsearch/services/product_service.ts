import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs/internal/Observable";
import { Product } from "src/models/product";
import { Constants } from "src/utils/constants";
import { map } from 'rxjs';
import { Injectable } from "@angular/core";
import { CategoryService } from "./category_services";
@Injectable()
export class ProductService{
    constructor(private http:HttpClient, private category:CategoryService){

    }
    loadAllProducts() :Observable<Product[]>{
        console.log(this.category.getCategory());
        console.log('going to make a Server call for Products....');
        let obs: Observable<Product[]> = this.http.get<{[key:string]:Product}>(Constants.URL).pipe(map((response:any)=>{
            const productsModel: Product[] = [];
            const products = response['products'];
              for(let key in products){
                const singleProd:any = products[key];
                const product = new Product(singleProd['id'], singleProd['name'], singleProd['price'], singleProd['image']);
                console.log('Map ',products[key]);
                productsModel.push(product);
              }
              return productsModel; // Array of Product return
          }));
          return obs;

    }
}