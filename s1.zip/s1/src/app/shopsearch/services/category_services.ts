import { Injectable } from "@angular/core";

@Injectable()
export class CategoryService{
    getCategory():String[]{
        return ["Mobile", "Laptop", "Tablets"];
    }
}