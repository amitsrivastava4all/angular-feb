import { Component, OnInit } from '@angular/core';
import { Cart } from '../../services/cart_service';

@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {

  constructor(private cart:Cart) { }

  ngOnInit(): void {
  }

  plus():void{
      this.cart.plus();
  }

}
