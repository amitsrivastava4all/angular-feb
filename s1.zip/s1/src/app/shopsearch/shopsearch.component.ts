import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { map } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { Product } from 'src/models/product';
import { Constants } from 'src/utils/constants';
import { ProductService } from './services/product_service';

@Component({
  selector: 'app-shopsearch',
  templateUrl: './shopsearch.component.html',
  styleUrls: ['./shopsearch.component.css']
})
export class ShopsearchComponent implements OnInit {
  products:Product[] = [];
  // Do the Dependency Injection (DI) - Service Object creation is handle by the Angular
  //productSer : ProductService = new ProductService(); // Object Creation
  constructor(private  productService:ProductService){}
  //constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.fetchAllProducts();
  }
  private fetchAllProducts(){
    console.log('Fetch All Products');

    // let obs: Observable<any> = this.http.get(Constants.URL);
    // obs.subscribe({next: (response:any)=>{
    //   console.log('Response is :::: ', response);
    // }, error: (err:HttpErrorResponse)=>{
    //   console.log('Error is ', err.message, err.status);
    // },complete: ()=>{
    //   console.log('Completed ');
    // }})
      let obs = this.productService.loadAllProducts();
      obs.subscribe({next: (response:Product[])=>{
        this.products = response;
        console.log('Response is :::: ', response);
      }, error: (err:HttpErrorResponse)=>{
        console.log('Error is ', err.message, err.status);
      },complete: ()=>{
        console.log('Completed ');
      }})
  }

}
