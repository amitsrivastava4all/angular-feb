import { Component, EventEmitter, OnInit } from '@angular/core';

import { Cart } from '../services/cart_service';

@Component({
  selector: 'app-totalitemincart',
  templateUrl: './totalitemincart.component.html',
  styleUrls: ['./totalitemincart.component.css']
})
export class TotalitemincartComponent implements OnInit {
  cartCount : number;
  constructor(private cart:Cart) {
    this.cartCount  = 0;
    this.getCartValue();
  }

  ngOnInit(): void {
  }

  getCartValue():void {
      let eventEmitter:EventEmitter<number> = this.cart.read();
      eventEmitter.subscribe({next:(value:number)=>{
        this.cartCount = value;

    },
    error: (err:any)=>console.log('Error ', err), complete: ()=>console.log('Complete')
  }
  );
  }

}
