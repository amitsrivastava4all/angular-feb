import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TotalitemincartComponent } from './totalitemincart.component';

describe('TotalitemincartComponent', () => {
  let component: TotalitemincartComponent;
  let fixture: ComponentFixture<TotalitemincartComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TotalitemincartComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TotalitemincartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
