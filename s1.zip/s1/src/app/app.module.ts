import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ShopsearchComponent } from './shopsearch/shopsearch.component';
import { TitleComponent } from './shopsearch/title/title.component';
import { SearchboxComponent } from './shopsearch/searchbox/searchbox.component';
import { ListComponent } from './shopsearch/list/list.component';
import { ItemComponent } from './shopsearch/list/item/item.component';
import { TotalitemincartComponent } from './shopsearch/totalitemincart/totalitemincart.component';
import {HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { ProductService } from './shopsearch/services/product_service';
import { CategoryService } from './shopsearch/services/category_services';
import { Cart } from './shopsearch/services/cart_service';
import { TokenInterceptor } from './shopsearch/interceptors/token_interceptor';
@NgModule({
  declarations: [
    AppComponent,
    ShopsearchComponent,
    TitleComponent,
    SearchboxComponent,
    ListComponent,
    ItemComponent,
    TotalitemincartComponent
  ],
  imports: [
    BrowserModule, HttpClientModule
  ],
  providers:[ProductService, CategoryService,{provide:HTTP_INTERCEPTORS,
    useClass: TokenInterceptor, multi:true}],
  //providers:[ProductService, CategoryService,Cart], // Object Creation By Framework is because of this
  //providers: [ProductService],
  // Acting like a Singleton
  //Service Instance is Application Wide Avaliable
  bootstrap: [AppComponent]
})
export class AppModule { }
