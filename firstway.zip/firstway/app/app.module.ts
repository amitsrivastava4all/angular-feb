import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { PrefixPipe } from 'src/prefix.pipe';

import { AppComponent } from './app.component';
import { CubePipe } from './cube.pipe';
import { SalarycalcComponent } from './salarycalc/salarycalc.component';
import { SalaryinputComponent } from './salarycalc/salaryinput/salaryinput.component';
import { SalaryoutputComponent } from './salarycalc/salaryoutput/salaryoutput.component';

@NgModule({
  declarations: [
    AppComponent, PrefixPipe, CubePipe, SalarycalcComponent, SalaryinputComponent, SalaryoutputComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
