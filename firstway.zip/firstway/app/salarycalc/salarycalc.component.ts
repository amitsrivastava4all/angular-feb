import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salarycalc',
  templateUrl: './salarycalc.component.html',
  styleUrls: ['./salarycalc.component.css']
})
export class SalarycalcComponent implements OnInit {
  basicSalary:number;
  constructor() {
    this.basicSalary  = 0.0;
  }

  ngOnInit(): void {
  }
  takeChildBasicSalary(basicSalary:number){
    this.basicSalary = basicSalary;
    console.log('Child Salary Rec in Parent Component ', basicSalary);
  }

}
