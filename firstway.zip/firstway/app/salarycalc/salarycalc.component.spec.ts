import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalarycalcComponent } from './salarycalc.component';

describe('SalarycalcComponent', () => {
  let component: SalarycalcComponent;
  let fixture: ComponentFixture<SalarycalcComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SalarycalcComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SalarycalcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
