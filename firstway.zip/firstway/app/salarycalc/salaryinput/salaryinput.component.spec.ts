import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalaryinputComponent } from './salaryinput.component';

describe('SalaryinputComponent', () => {
  let component: SalaryinputComponent;
  let fixture: ComponentFixture<SalaryinputComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SalaryinputComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SalaryinputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
