import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-salaryinput',
  templateUrl: './salaryinput.component.html',
  styleUrls: ['./salaryinput.component.css']
})
export class SalaryinputComponent implements OnInit {
  basicSalary:number;
  @Output()
  recchildsalary:EventEmitter<number> = new EventEmitter<number>();
  constructor() {
    this.basicSalary  = 0.0;
  }

  computeIt(){
      console.log('Compute It Button Clicked ', this.basicSalary);
      this.recchildsalary.emit(this.basicSalary); // send value to the parent function
  }

  ngOnInit(): void {
  }

  takeSalary(event:any){
      this.basicSalary = parseFloat(event?.target?.value);
      console.log("Basic Salary ", this.basicSalary);
  }

}
