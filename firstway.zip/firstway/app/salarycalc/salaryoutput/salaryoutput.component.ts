import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-salaryoutput',
  templateUrl: './salaryoutput.component.html',
  styleUrls: ['./salaryoutput.component.css']
})
export class SalaryoutputComponent implements OnInit {
  @Input()
  bs:number;
  constructor() {
    this.bs = 0;
  }
  hra(){
    return this.bs * 0.30;
  }
  da(){
    return this.bs * 0.20;
  }
  ta(){
    return this.bs * 0.10;
  }
  ngOnInit(): void {
  }

}
