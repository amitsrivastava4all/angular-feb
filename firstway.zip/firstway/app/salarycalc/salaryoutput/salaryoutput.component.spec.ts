import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SalaryoutputComponent } from './salaryoutput.component';

describe('SalaryoutputComponent', () => {
  let component: SalaryoutputComponent;
  let fixture: ComponentFixture<SalaryoutputComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SalaryoutputComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SalaryoutputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
