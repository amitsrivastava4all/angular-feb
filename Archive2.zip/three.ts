const obj:{id:number, name:string, address?:{city:string,country:string}} = {
    id:1001, name:'ram', 
    // address:{
    //     city:'Delhi',
    //     country:'India'
    // }
};
console.log(obj);
console.log((obj.address?.city)??"No Address");
var e:string;
var obj2 = null;
console.log(obj2??"NA");
console.log(e??"Nothing");
