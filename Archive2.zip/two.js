"use strict";
//function add(x:number|string, y:number|string):number|string{
//     function add(x:string, y:number):string;
//     function add(x:number, y:string):string{
function add(x, y) {
    if (typeof x === 'string' && typeof y === 'string') {
        var z = parseInt(x) + parseInt(y);
        return z.toString();
    }
    else if (typeof x === 'string' && typeof y === 'number') {
        var z = parseInt(x) + y;
        return z.toString();
    }
    else if (typeof x === 'number' && typeof y === 'string') {
        var z = x + parseInt(y);
        return z.toString();
    }
    else if (typeof x === 'number' && typeof y === 'number') {
        return (x + y).toString();
    }
    return "0";
}
//var c :string|number = add(10,20);
var c = add("10", 20);
console.log(c);
console.log(200, 100);
console.log(20, "10");
console.log();
//var d:string|number  = add("Hello", "Bye");
var d = add("10", "20");
console.log(d);
