"use strict";
var x;
x = "Hello";
x = true;
x = 1000;
var e;
e = x;
console.log(e);
var y;
var b;
var d;
d = 1000;
//d = "Hello";
y = 100;
y = "Hello";
//y = true;
var z;
//z = y;
if (typeof y === 'string') {
    z = y;
    console.log('Z is ', z);
}
else {
    console.log('Not Assign boolean to string');
}
function show() {
    return undefined;
}
function test() {
    return null;
}
