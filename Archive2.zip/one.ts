var x:any;
x= "Hello";
x = true;
x = 1000;
var e:string;
e = x;
console.log(e);
var y:unknown;
var b:undefined;
var d:number;
d = 1000;
//d = "Hello";
y = 100;
y = "Hello";
//y = true;
var z:string;
//z = y;
if(typeof y ==='string'){
z = y;
console.log('Z is ',z);
}
else{
    console.log('Not Assign boolean to string');
}


function show():undefined{
    return undefined;
}

function test():object{
    return null;
}