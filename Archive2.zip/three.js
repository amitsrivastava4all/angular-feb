"use strict";
var _a, _b;
const obj = {
    id: 1001, name: 'ram',
    // address:{
    //     city:'Delhi',
    //     country:'India'
    // }
};
console.log(obj);
console.log((_b = ((_a = obj.address) === null || _a === void 0 ? void 0 : _a.city)) !== null && _b !== void 0 ? _b : "No Address");
var e;
var obj2 = null;
console.log(obj2 !== null && obj2 !== void 0 ? obj2 : "NA");
console.log(e !== null && e !== void 0 ? e : "Nothing");
