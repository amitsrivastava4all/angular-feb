"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
//function CustomerInfo(constructor:Function){
// Decorator Factory
function CustomerInfo(message, id) {
    //console.log("I am a Customer Info Decorator.... ", constructor);
    return function (constructor) {
        constructor.prototype.print = function () {
            console.log(`Id ${this.id} Name ${this.name}`);
        };
        const h1 = document.querySelector('#' + id);
        if (h1) {
            h1.innerHTML = message;
        }
        console.log("Html + Now Prototype of Customer is ", constructor.prototype);
    };
}
function CustomerInfo2(fn) {
    fn.prototype.x = 1000;
}
let Customer = class Customer {
    constructor(id, name) {
        this.id = id;
        this.name = name;
    }
};
Customer = __decorate([
    CustomerInfo2,
    CustomerInfo('Hello TS', 'output')
], Customer);
var amit = new Customer(1001, "Amit");
amit.print();
console.log(amit.x);
