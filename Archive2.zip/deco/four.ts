//function CustomerInfo(constructor:Function){
    // Decorator Factory
    function CustomerInfo(message:string, id:string){
    //console.log("I am a Customer Info Decorator.... ", constructor);
    return function (constructor:Function){
    constructor.prototype.print = function(){
        console.log(`Id ${this.id} Name ${this.name}`);
    }
    const h1 = document.querySelector('#'+id);
    if(h1){
    h1.innerHTML = message;
    }
    console.log("Html + Now Prototype of Customer is ", constructor.prototype);
    }
}
function CustomerInfo2(fn:Function){
    fn.prototype.x = 1000;
}
@CustomerInfo2
@CustomerInfo('Hello TS','output')
class Customer{
    id:number;
    name:string;
    constructor(id:number, name:string){
        this.id = id;
        this.name = name;
    }
}
var amit:Customer =new Customer(1001, "Amit");

(<any>amit).print();
console.log((<any>amit).x);