import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sides',
  templateUrl: './sides.component.html',
  styleUrls: ['./sides.component.css']
})
export class SidesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
