import { Component, OnInit } from '@angular/core';
import './menu.component.css';
@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit {
  discount:number ;
  days:number;
  constructor() {
    this.discount = 0.0;
    this.days = 0;
   }

  ngOnInit(): void {
  }

  update(dis:HTMLInputElement, day:HTMLInputElement){
        this.discount = parseFloat(dis.value);
        this.days = parseFloat(day.value);

  }

}
