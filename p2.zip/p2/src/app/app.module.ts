import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { DealsComponent } from './deals/deals.component';
import { PizzasComponent } from './pizzas/pizzas.component';
import { SidesComponent } from './sides/sides.component';
import { DessertsComponent } from './desserts/desserts.component';
import { DrinksComponent } from './drinks/drinks.component';
import { PizzahomeComponent } from './pizzahome/pizzahome.component';
import { MenuComponent } from './widgets/menu/menu.component';
import { RouterModule, Routes } from '@angular/router';
import { ErrorComponent } from './utils/component/error/error.component';
import { PizzaModuleRouting } from './app.pizzarouting.module';
import { SoftComponent } from './drinks/soft/soft.component';
import { HotComponent } from './drinks/hot/hot.component';
import {HttpClientModule} from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PcardComponent } from './widgets/pcard/pcard.component';
import {MatCardHeader, MatCardModule, MatCardTitle} from '@angular/material/card';

@NgModule({
  declarations: [
    AppComponent,
    DealsComponent,
    PizzasComponent,
    SidesComponent,
    DessertsComponent,
    DrinksComponent,
    PizzahomeComponent,
    MenuComponent,
    ErrorComponent,
    SoftComponent,
    HotComponent,
    PcardComponent
  ],
  imports: [
    BrowserModule,PizzaModuleRouting, HttpClientModule,
    BrowserAnimationsModule,
     MatCardModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
