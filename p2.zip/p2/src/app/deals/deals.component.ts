import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deals',
  templateUrl: './deals.component.html',
  styleUrls: ['./deals.component.css']
})
export class DealsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  canComponentDeactivate(){
    console.log('Cleanning the Resource use by the component');
    // stream subscribe , unsubscribe
  }

}
