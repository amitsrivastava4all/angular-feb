import { Component, isDevMode, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'pizzashop';
  ngOnInit(): void {
      if(isDevMode()){
        console.log("I am in Development Mode");
      }
      else{
        console.log("I am in the Production Mode");
      }
  }
}
