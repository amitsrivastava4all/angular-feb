import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot,
    CanActivate, CanActivateChild, Router, RouterStateSnapshot,
    UrlTree } from "@angular/router";
import { Observable } from "rxjs";
@Injectable({providedIn:'root'})
export class AuthGuardService implements CanActivate, CanActivateChild{
    isAuthorize:boolean ;
    constructor(private route:Router){
        this.isAuthorize = true;
    }
    canActivateChild(childRoute: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
            console.log("Child Auth Guard.....");
            if(this.isAuthorize){
            return true;
        }
        else{
            return this.route.navigate(['/']); // auth false move to home comoponent
        }
    }
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
       console.log('Auth Guard Run.....');
        if(this.isAuthorize){
            return true;
        }
        else{
            return this.route.navigate(['/']); // auth false move to home comoponent
        }
    }

}