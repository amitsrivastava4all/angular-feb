import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot, UrlTree } from "@angular/router";
import { Observable } from "rxjs";
import { DealsComponent } from "src/app/deals/deals.component";
@Injectable({providedIn:'root'})
export class AuthDeactiveGuardService implements CanDeactivate<DealsComponent>{
    canDeactivate(component: DealsComponent, currentRoute: ActivatedRouteSnapshot, currentState: RouterStateSnapshot, nextState?: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
        console.log('Component DeActive Guard call....');
        component.canComponentDeactivate();
        return true;
    }

}