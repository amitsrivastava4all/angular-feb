import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-soft',
  templateUrl: './soft.component.html',
  styleUrls: ['./soft.component.css']
})
export class SoftComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
