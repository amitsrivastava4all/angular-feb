import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-drinks',
  templateUrl: './drinks.component.html',
  styleUrls: ['./drinks.component.css']
})
export class DrinksComponent implements OnInit {
  discount:number =0.0;
  constructor(private router:Router, private activeRoute:ActivatedRoute) { }

  ngOnInit(): void {
    this.discount = this.activeRoute.snapshot.params['discount'];
   // this.moveToNextPage();
  }
  moveToNextPage():void{
    this.router.navigate(['/pizzas'],{queryParams:{discount:35, days:3}});
  }

}
