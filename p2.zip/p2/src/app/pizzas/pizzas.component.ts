import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { PizzaService } from '../services/pizza.service';

@Component({
  selector: 'app-pizzas',
  templateUrl: './pizzas.component.html',
  styleUrls: ['./pizzas.component.css']
})
export class PizzasComponent implements OnInit {
  //discount:number =0.0;
  pizzaOffers :{discount:number, days:number} = {discount:0.0, days:0};
  constructor(private route:ActivatedRoute, private pizzaService:PizzaService) { }

  ngOnInit(): void {
    this.pizzaOffers = {
      discount: this.route.snapshot.queryParams['discount'],
      days: this.route.snapshot.queryParams['days']
      //discount: this.route.snapshot.params['discount'],
      //days: this.route.snapshot.params['limit']

    }
    let obs:Observable<any> = this.pizzaService.getPizzas();
    obs.subscribe({next:(value)=>{
      console.log('Value is ',value);
    }, error:(err)=>{
      console.log('Error in Pizza ' , err);
    },complete:()=>{
      console.log('Completed... ');
    }})

  }

}
