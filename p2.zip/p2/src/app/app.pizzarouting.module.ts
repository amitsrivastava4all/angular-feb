import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { DealsComponent } from "./deals/deals.component";
import { DessertsComponent } from "./desserts/desserts.component";
import { DrinksComponent } from "./drinks/drinks.component";
import { HotComponent } from "./drinks/hot/hot.component";
import { SoftComponent } from "./drinks/soft/soft.component";
import { PizzasComponent } from "./pizzas/pizzas.component";
import { AuthDeactiveGuardService } from "./services/guards/auth-deactivate-guard.service";
import { AuthGuardService } from "./services/guards/auth-guard.service";
import { SidesComponent } from "./sides/sides.component";
import { ErrorComponent } from "./utils/component/error/error.component";
const pizzaRoutes:Routes = [
    {path : '', component: DealsComponent, canDeactivate:[AuthDeactiveGuardService]},
    // {path:'pizzas/:discount/:limit', component:PizzasComponent},
    {path:'pizzas', component:PizzasComponent},
    {path: 'sides', component:SidesComponent},
    {path:'desserts', component:DessertsComponent,
     //canActivate:[AuthGuardService]
    },
    {path:'drinks/:discount', component:DrinksComponent,
    canActivateChild:[AuthGuardService],
    children:[
      {path:'colddrinks', component:SoftComponent},{path:'hotdrinks', component:HotComponent}
    ]},
    {path:'error-page', component:ErrorComponent},
    {path:'**',redirectTo:'/error-page'}
  ];
@NgModule({
    imports:[
      RouterModule.forRoot(pizzaRoutes,
        {useHash:true})], exports:[RouterModule]
})
export class PizzaModuleRouting{

}