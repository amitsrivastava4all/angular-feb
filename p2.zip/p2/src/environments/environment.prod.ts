export const environment = {
  production: true,
  PIZZA_URL:'<PROD URL>'

};
