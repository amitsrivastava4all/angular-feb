// Variable Declare
var first:number; // Explicit Way 
first= 100;
var second = 200; // Implicit Way / Type Inference
second = 900;
var result:number = first + second;
console.log(result);
var myName:string ;
myName = 'Amit';
console.log(myName);
var name1 = "Ram";
console.log(name1);
var z:number = 21;
z = 0xf22b; // Hexa
z = 0o655; // Octal
z = 90.345454;
var y:bigint = 8737534534534535345345n;
var att:boolean ;
att = true;
//att = 10000;
var att2= true;
var b:any ;
b = "hello";
b = true;
b = 9000;
console.log(b);
