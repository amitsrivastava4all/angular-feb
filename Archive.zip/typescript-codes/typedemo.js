function takeEmp(emp) {
    console.log('Emp is ', emp);
}
takeEmp({ id: 1001, name: 'Ram', salary: 11111 });
