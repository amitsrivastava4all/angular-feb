enum Direction{
    UP = 1,
    DOWN = 2,
    LEFT = 3,
    RIGHT = 4
    
}
const key:Direction = Direction.UP;
if(key == Direction.UP){

}
else if (key == Direction.DOWN){

}