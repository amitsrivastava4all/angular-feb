//var d1:number = 1;
enum DAY  {
    SUNDAY = 1, MONDAY = 2, TUESDAY 
};
var d1:DAY = 10>2?DAY.SUNDAY:DAY.MONDAY;
console.log("D1 is ",d1);
switch(d1){
    case DAY.SUNDAY:
    //case 1:
        console.log('Holiday');
        break;
    case DAY['MONDAY']:
        //case 2:
        console.log('Working Day');
        break;    
}
console.log(d1); // 1
console.log(d1 + DAY.MONDAY);


