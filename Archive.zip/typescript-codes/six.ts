function show(x:number, y:number):number{
    return x + y;
}

function disp():void{
    
}
var result = show(10,20);

var add:(x:number, y:number)=>number;

add = show;
//add = disp;
result = add(10,20);


//var s:string = "1000";
// function disp2(x:number)
function disp2(add:(x:number, y:number)=>number){

}
disp2(show);
//disp2(disp);
//disp2(100);



