var ar3:string[] = ["amit","ram","shyam"];
var a4 = ["amit","ram"];
var a5:Array<string> = new Array<string>(10);
// Tuples
var a6:[string, number] = ["amit",1001];
console.log(a6[0]);
console.log(a6[1]);

// Enums
const SUNDAY = 1;
const MONDAY = 2;
enum Days {
    SUNDAY=1, MONDAY=2, TUESDAY
};
enum Mix{
    //YES = "yes",
    NO = 0,
    LEN = "Amit".length
}
enum Mix2{
    ACCEPT = "a",
    YES = 1,
    DECLINE = "d",
    NO = 1
}
enum CarType{
    SUV = "SUV",
    SEDAN = "SEDAN"
}
console.log(CarType.SUV);
console.log(CarType['SEDAN']);
var day:Days = Days.TUESDAY;
console.log(day);
switch(day){
    case SUNDAY:
        console.log("Holiday");
        break;

    case MONDAY:
        console.log("Working Day");
        break;
}