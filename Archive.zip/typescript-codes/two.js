var e = { name: 'AAAA' };
var w = {};
w.a = 10;
w.b = 20;
w.z = 90;
console.log(w);
var x = { id: 101, name: 'Ram', salary: 9999 };
var y1;
var z2;
var obj = {
    name: 'Amit',
    city: 'Delhi'
}; // Implicit / Type Inference
// Explicit
var obj2 = {
    name: 'Ram', city: 'Delhi', age: 21
};
//obj2.phone = 4444;
console.log(obj);
var arr = [10, 20, 30];
var arr2 = [100, 200, 300];
var arr4 = ["Amit", "Ram"]; // Generic Way
var arr5 = new Array(10);
arr5.push("abcd");
var dd = arr5.pop();
console.log(arr5);
var arr3 = [10, true, "Hello"];
var d = "Hello";
d = true;
