var ar3 = ["amit", "ram", "shyam"];
var a4 = ["amit", "ram"];
var a5 = new Array(10);
// Tuples
var a6 = ["amit", 1001];
console.log(a6[0]);
console.log(a6[1]);
// Enums
var SUNDAY = 1;
var MONDAY = 2;
var Days;
(function (Days) {
    Days[Days["SUNDAY"] = 1] = "SUNDAY";
    Days[Days["MONDAY"] = 2] = "MONDAY";
    Days[Days["TUESDAY"] = 3] = "TUESDAY";
})(Days || (Days = {}));
;
var Mix;
(function (Mix) {
    //YES = "yes",
    Mix[Mix["NO"] = 0] = "NO";
    Mix[Mix["LEN"] = "Amit".length] = "LEN";
})(Mix || (Mix = {}));
var CarType;
(function (CarType) {
    CarType["SUV"] = "SUV";
    CarType["SEDAN"] = "SEDAN";
})(CarType || (CarType = {}));
console.log(CarType.SUV);
console.log(CarType['SEDAN']);
var day = Days.TUESDAY;
console.log(day);
switch (day) {
    case SUNDAY:
        console.log("Holiday");
        break;
    case MONDAY:
        console.log("Working Day");
        break;
}
