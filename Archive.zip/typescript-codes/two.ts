
type myType = {
    id?:number, name:string, salary?:number
};

var e:myType = {name:'AAAA'};

var w:any  = {} ;
w.a = 10;
w.b = 20;
w.z = 90;
console.log(w);


var x:myType = {id:101,name:'Ram',salary:9999};
var y1 :myType;
var z2:myType;

var obj = {
    name:'Amit',
    city:'Delhi'
} // Implicit / Type Inference
// Explicit
var obj2: {name:string, city:string, age:number} = {
    name:'Ram', city:'Delhi', age:21
};
//obj2.phone = 4444;
console.log(obj);
var arr = [10,20,30];
var arr2:number[] = [100,200,300];
var arr4:Array<string> = ["Amit","Ram"]; // Generic Way
var arr5:Array<string> = new Array<string>(10);
arr5.push("abcd");
var dd = arr5.pop();
console.log(arr5);
var arr3 = [10,true, "Hello"];

var d:string|boolean = "Hello";
d = true;