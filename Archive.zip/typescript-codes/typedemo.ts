type Emp = {
    id:number, name:string, salary:number
}

type Fn = (x:number , y:number)=>number;


function takeFn(a:Fn){

}

function takeEmp(emp:Emp){
    console.log('Emp is ',emp);
}
takeEmp({id:1001, name:'Ram',salary:11111});

function iNeverCompleteSuccessFully():never{
    throw new Error("Error Generated....");
}
