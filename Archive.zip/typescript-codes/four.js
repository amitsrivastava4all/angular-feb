//var d1:number = 1;
var DAY;
(function (DAY) {
    DAY[DAY["SUNDAY"] = 1] = "SUNDAY";
    DAY[DAY["MONDAY"] = 2] = "MONDAY";
    DAY[DAY["TUESDAY"] = 3] = "TUESDAY";
})(DAY || (DAY = {}));
;
var d1 = 10 > 2 ? DAY.SUNDAY : DAY.MONDAY;
console.log("D1 is ", d1);
switch (d1) {
    case DAY.SUNDAY:
        //case 1:
        console.log('Holiday');
        break;
    case DAY['MONDAY']:
        //case 2:
        console.log('Working Day');
        break;
}
console.log(d1); // 1
console.log(d1 + DAY.MONDAY);
