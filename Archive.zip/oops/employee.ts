class Employee{
     private _id:number; 
     private _name:string;
     private _salary:number;
     private _phone:string;
     private _email:string;

    public get id(): number {
        return this._id;
    }

   

    public get name(): string {
        return this._name;
    }

    public set name(name: string) {
        this._name = name;
    }

    public get salary(): number {
        return this._salary;
    }

    public set salary(salary: number) {
        if(salary>0){
        this._salary = salary;
        }
        else{
            console.log('Wrong Salary Enter , Negative Salary')
        }
    }

    public get phone(): string {
        return this._phone;
    }

    public set phone(phone: string) {
        this._phone = phone;
    }

    public get email(): string {
        return this._email;
    }

    public set email(email: string) {
        
        console.log('Set Email');
        this._email = email;
    }

    constructor(id:number, name:string, salary:number){
        this._id = id;
        this._name = name;
        this._salary = salary;
        this._phone = this._email ="";
    }
   

    public show():void{
        console.log( `Id is ${this.id} Name ${this.name} Salary ${this.salary}`);
    }

}
var ram:Employee = new Employee(1001, "Ram",1111); // Constructor Call
ram.email = "ram@yahoo.com";
ram.salary = -9000; // setter call
ram.show();
//console.log(ram.id, ram.name, ram.salary);