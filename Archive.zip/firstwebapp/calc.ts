var count:number = 0;
function show():void{
    count+=5;
    var ele:HTMLSpanElement= document.querySelector('#count');
    ele.innerHTML = count.toString();
}


