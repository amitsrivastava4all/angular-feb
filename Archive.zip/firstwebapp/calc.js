var count = 0;
function show() {
    count += 5;
    var ele = document.querySelector('#count');
    ele.innerHTML = count.toString();
}
