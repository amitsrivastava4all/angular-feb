import { Component } from "@angular/core";

@Component({
    selector:'app-child',
    //templateUrl:'./child.component.html',
    template:`<h1 class='mystyle2'> {{title}} </h1> <app-third></app-third> <app-fifth></app-fifth>`,
    //styleUrls:['./child.component.css']
    styles:[`
    .mystyle2{
    color:orange;
}
    `]
})
export class ChildComponent{
    title:string;
    constructor(){
        this.title = 'Hello I am Child......'
    }
}