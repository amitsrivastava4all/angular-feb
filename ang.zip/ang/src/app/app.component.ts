import { Component } from '@angular/core';

// Like a Controller (View Interact) I(Read Data From View) /O (Write Data to View)
// 1. O - String Interpolation {{data}}
// 2. 0 - Property Binding [] Box Syntax 
// I - Event Binding () Banana Syntax
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular - 2022';
  myname:string;
  count:number;
  constructor(){
    this.myname = "";
    this.count = 0;
  }
  plus():void{
    console.log('Plus Fn Call....');
      this.count++;
  }
  takeInput(event:any){
    let name = event.target.value;
    this.title = name;
    console.log('Name is ',name);
  }
}
