interface TMath{ // What to Do?
    pow(num:number, exp:number):number;
    sqrt(num:number):number;
}


// How to do?
class MathImpl implements TMath{
    pow(num: number, exp: number): number {
       console.log('Pow ');
       return 0;
    }
    sqrt(num: number): number {
       // throw new Error("Method not implemented.");
       console.log('Sqrt');
       return 2;
    }

}
var m:MathImpl = new MathImpl();
m.sqrt(3);