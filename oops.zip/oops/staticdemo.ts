class User{
    // Instance Variables - When Object is created
    userName:string;
    password:string;
    static count:number=0; // During Class Load so Attach with Class
    static readonly MAX:number = 100;
    constructor(userName:string, password:string){
        this.userName = userName;
        this.password = password;
        //this.count++;
        User.count++;
        //User.MAX++;
        console.log('User Login ', User.count);
    }
}
var user:User = new User('amit','1111');
var user2:User = new User('ram','1111');
var user3:User = new User('ramesh','1111');

class MathOpr{
    static abs():void{
        console.log('Abs');
    }
}
MathOpr.abs();