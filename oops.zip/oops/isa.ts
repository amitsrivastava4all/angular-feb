declare function add(x:number, y:number):number;
console.log('calling add ', add(10,20));
abstract class Account{
    protected aid:number; // Instance Members
    protected aname:string;
    protected balance:number;
    protected city?:string;
    private declare country:number;
    constructor(aid:number, aname:string, balance:number, city:string='Delhi'){
        console.log('Account Class Cons Call');
        this.aid = aid;
        this.aname = aname;
        this.balance = balance;
        this.city = city;
    }
    
    // Constructor ShortHand
    //constructor(protected aid:number, protected aname:string, protected balance:number){}
    print():void{
        console.log(`Id ${this.aid} Name ${this.aname} Balance ${this.balance} City is ${this.city}`);
    }
    abstract computeROI():void;

}
class SavingAccount extends Account{
    limit:number;
    roi:number;
    constructor(aid:number, aname:string, balance:number,limit:number, roi:number){
       // super(aid, aname, balance); // super is a reserved keyword , used to call parent class constructor in this case
        console.log('SavingAccount Class Cons Call');
        super(aid, aname, balance, 'Mumbai');
        this.limit = this.balance / 2;
        this.roi = roi;
        
    }
    computeROI():void{
        console.log("SavingAccount ROI");
    }
    print():void{
        super.print(); 
        console.log(`Limit ${this.limit} ROI ${this.roi}`);
    }
}
declare class CurrentAccount{

}
//var account:Account= new Account(1001, 'Ram',9999);
var savingAccount:SavingAccount = new SavingAccount(1001, 'Ram',9999,4000, 4);
 savingAccount.print();
 savingAccount.computeROI();
// savingAccount.display();