var a;
// function printPerson(person:Person){
// }
// function print2(person:{name:string, age:number, city:string}){
// }
// interface Person{
//     name:string, age?:number, city:string
// }
// interface Student extends Person{
//     course:string, duration:number
// }
function printPerson(person) {
    console.log(person);
}
function printStudent(student) {
    console.log(student);
}
printPerson({ name: 'A', city: 'Delhi' });
printStudent({ course: 'TS', duration: 2, name: 'A', city: 'D' });
