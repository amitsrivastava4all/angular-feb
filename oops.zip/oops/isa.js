var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
console.log('calling add ', add(10, 20));
var Account = /** @class */ (function () {
    function Account(aid, aname, balance, city) {
        if (city === void 0) { city = 'Delhi'; }
        console.log('Account Class Cons Call');
        this.aid = aid;
        this.aname = aname;
        this.balance = balance;
        this.city = city;
    }
    // Constructor ShortHand
    //constructor(protected aid:number, protected aname:string, protected balance:number){}
    Account.prototype.print = function () {
        console.log("Id ".concat(this.aid, " Name ").concat(this.aname, " Balance ").concat(this.balance, " City is ").concat(this.city));
    };
    return Account;
}());
var SavingAccount = /** @class */ (function (_super) {
    __extends(SavingAccount, _super);
    function SavingAccount(aid, aname, balance, limit, roi) {
        var _this = this;
        // super(aid, aname, balance); // super is a reserved keyword , used to call parent class constructor in this case
        console.log('SavingAccount Class Cons Call');
        _this = _super.call(this, aid, aname, balance, 'Mumbai') || this;
        _this.limit = _this.balance / 2;
        _this.roi = roi;
        return _this;
    }
    SavingAccount.prototype.computeROI = function () {
        console.log("SavingAccount ROI");
    };
    SavingAccount.prototype.print = function () {
        _super.prototype.print.call(this);
        console.log("Limit ".concat(this.limit, " ROI ").concat(this.roi));
    };
    return SavingAccount;
}(Account));
//var account:Account= new Account(1001, 'Ram',9999);
var savingAccount = new SavingAccount(1001, 'Ram', 9999, 4000, 4);
savingAccount.print();
savingAccount.computeROI();
// savingAccount.display();
