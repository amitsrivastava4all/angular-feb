var User = /** @class */ (function () {
    function User(userName, password) {
        this.userName = userName;
        this.password = password;
        //this.count++;
        User.count++;
        console.log('User Login ', User.count);
    }
    User.count = 0; // During Class Load so Attach with Class
    return User;
}());
var user = new User('amit', '1111');
var user2 = new User('ram', '1111');
var user3 = new User('ramesh', '1111');
