type Person = {
    name:string, age?:number, city:string
}
var a :number|string;
type Student = Person & {course:string, duration:number};
// function printPerson(person:Person){

// }
// function print2(person:{name:string, age:number, city:string}){

// }
// interface Person{
//     name:string, age?:number, city:string
// }
// interface Student extends Person{
//     course:string, duration:number
// }
function printPerson(person:Person){
    console.log(person);
}
function printStudent(student:Student){
    console.log(student);
}
printPerson({name:'A', city:'Delhi'});
printStudent({course:'TS',duration:2,name:'A',city:'D'});
