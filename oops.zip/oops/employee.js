class Employee {
    constructor(id, name, salary) {
        this._id = id;
        this._name = name;
        this._salary = salary;
        this._phone = this._email = "";
    }
    get id() {
        return this._id;
    }
    get name() {
        return this._name;
    }
    set name(name) {
        this._name = name;
    }
    get salary() {
        return this._salary;
    }
    set salary(salary) {
        if (salary > 0) {
            this._salary = salary;
        }
        else {
            console.log('Wrong Salary Enter , Negative Salary');
        }
    }
    get phone() {
        return this._phone;
    }
    set phone(phone) {
        this._phone = phone;
    }
    get email() {
        return this._email;
    }
    set email(email) {
        console.log('Set Email');
        this._email = email;
    }
    show() {
        console.log(`Id is ${this.id} Name ${this.name} Salary ${this.salary}`);
    }
}
var ram = new Employee(1001, "Ram", 1111); // Constructor Call
ram.email = "ram@yahoo.com";
ram.salary = -9000; // setter call
ram.show();
//console.log(ram.id, ram.name, ram.salary);
