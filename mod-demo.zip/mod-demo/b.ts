namespace MathOperations{
    export function subtraction(x,y){
        return x - y;
    }
    export function sin(){
        console.log('Math Operation Sin');
    }
}