namespace MathOperations{
    export function addition(x,y){
        return x + y;
    }
    export namespace Tri{
        export function sin(){
            console.log('Tri Sin');
        }
    }
}