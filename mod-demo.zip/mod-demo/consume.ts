///<reference path="a.ts"/>
///<reference path="b.ts"/>
MathOperations.sin();
var result:number = MathOperations.addition(10,20);
console.log('Result ',result);
MathOperations.Tri.sin();