function callMe(x:any):any{
    x = "Hi";
    x = 100;
    x = true;
    console.log(x);
}
callMe(9999);

function genFn<T>(x:T):T{
    return x;
}
console.log(genFn("Hello").toUpperCase());
console.log(genFn(999).toFixed());

var arr:Array<number> = [10,20,30];
var arr2:Array<string> = ["Hello", "Hi"];
class A{

}
class B extends A{

}
class C extends A{

}
class D{

}
class Stack<T>{
    data:T;
    top:number;
    constructor(){
        this.top = -1;
        
    }
    push(d:T):void{

    }
    pop():T{
        return this.data;
    }
}
var stack:Stack<D> = new Stack<D>();
stack.push(new D());
var stack2:Stack<string> =new Stack<string>();
stack2.push("Hello");
var d:string = stack2.pop();