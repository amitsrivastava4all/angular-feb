export default class A{
    show():void{
        console.log("A Show");
    }
}
//const o = {disp, disp2};
export const disp = ()=>console.log('I am Disp');
export const disp2 = ()=>console.log('I am Disp');