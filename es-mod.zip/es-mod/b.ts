import A, {disp, disp2} from './a.js';
var a:A = new A();
disp();
disp2();
a.show();