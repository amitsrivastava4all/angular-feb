import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pizzahome',
  templateUrl: './pizzahome.component.html',
  styleUrls: ['./pizzahome.component.css']
})
export class PizzahomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
