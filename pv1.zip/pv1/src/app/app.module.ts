import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { DealsComponent } from './deals/deals.component';
import { PizzasComponent } from './pizzas/pizzas.component';
import { SidesComponent } from './sides/sides.component';
import { DessertsComponent } from './desserts/desserts.component';
import { DrinksComponent } from './drinks/drinks.component';
import { PizzahomeComponent } from './pizzahome/pizzahome.component';
import { MenuComponent } from './widgets/menu/menu.component';
import { RouterModule, Routes } from '@angular/router';
import { ErrorComponent } from './utils/component/error/error.component';
import { PizzaModuleRouting } from './app.pizzarouting.module';



@NgModule({
  declarations: [
    AppComponent,
    DealsComponent,
    PizzasComponent,
    SidesComponent,
    DessertsComponent,
    DrinksComponent,
    PizzahomeComponent,
    MenuComponent,
    ErrorComponent
  ],
  imports: [
    BrowserModule,PizzaModuleRouting
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
