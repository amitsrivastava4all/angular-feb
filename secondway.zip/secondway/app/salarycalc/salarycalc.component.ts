import { typeWithParameters } from '@angular/compiler/src/render3/util';
import { Component, OnInit, ViewChild } from '@angular/core';
import { SalaryinputComponent } from './salaryinput/salaryinput.component';

@Component({
  selector: 'app-salarycalc',
  templateUrl: './salarycalc.component.html',
  styleUrls: ['./salarycalc.component.css']
})
export class SalarycalcComponent implements OnInit {
  @ViewChild(SalaryinputComponent)
  salaryInputObject: SalaryinputComponent = new SalaryinputComponent();
  basicSalary:number;
  name:string;
  constructor() {
    this.name = "";
    this.basicSalary  = 0.0;
  }

  recName(name:string){
      this.name = name;
  }

  ngOnInit(): void {
  }
  takeChildBasicSalary(basicSalary:number){
    this.basicSalary = basicSalary;
    console.log('Child Salary Rec in Parent Component ', basicSalary);
    this.name = this.salaryInputObject.name;
  }

}
