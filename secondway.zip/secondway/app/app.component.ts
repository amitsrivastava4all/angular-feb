import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  salary:number  = 1233.545665;
   title:string;
   fruits:string[]  = [];
   count:number;
   jdate:Date;
   obj:{id:number, name:string, salary:number}= {id:1001, name:'Abcd', salary:88888};
   isLoggedIn:boolean = false;
  ngOnInit(): void {

    console.log("I call when Component is Initalized....");
    this.fruits = this.prepareData();
  }
  prepareData(){
    return ["Apple","Mango", "Orange"];

  }
  update(){
    this.isLoggedIn  = !this.isLoggedIn;
    this.count++;
  }
  constructor(){
    this.jdate = new Date();
    this.count = 0;
    console.log("I am a constructor....");
    this.title = 'Hello Angular';

  }


}
